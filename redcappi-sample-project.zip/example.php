<?php
// Include PHP class
require_once('rcapi.class.php');

/**
 *
 * update with your public and private keys.
 * obtain your keys from EXTRA section in RedCappi.com
 * You need to become user to get the keys
 */
 
	$public_key = 'YOUR-PUBLIC-KEY' ;
	$private_key = 'YOUR-PRIVATE-KEY' ;
	
	
	$api_domain = 'http://api.redcappi.com';
	$api_folder = '/v1';
 

$rcapi = new RedCappiClientApi($public_key, $private_key, $api_domain, $api_folder);

// --------------------------------------------------------------------------------------------
// List Management
// --------------------------------------------------------------------------------------------

/**
 * Get All Contact-Lists
 * Uncomment to view the example
 */

// echo $rcapi->showList(); exit;


/**
 * Get specific Contact-List for which ID is provided
 * Uncomment to view the example
 */

 // echo $rcapi->showList(3); exit;


/**
 * Add a new Contact-List
 * Uncomment to view the example
 */

// echo $rcapi->addList('kaalu 1'); exit;


/**
 * Rename a Contact-List
 * Uncomment to view the example
 */

 //echo $rcapi->renameList(2772, 'Renamed 20' ); exit;


/**
 * Delete a Contact-List
 * Uncomment to view the example
 */
 
// echo $rcapi->removeList(2772); exit;


// --------------------------------------------------------------------------------------------
// Contact Management
// --------------------------------------------------------------------------------------------


/**
 * Get list of contacts from provided List-Id
 * Uncomment to view the example
 */

 //echo $rcapi->showContacts(2540); exit;


/**
 * Get details of contact from provided List-Id and contact-Id
 * Uncomment to view the example
 */

 // echo $rcapi->showContact(2540,11751103); exit;



/**
 * Add a new contact to provided List-Id
 * Uncomment to view the example
 */

 //echo $rcapi->addContacts(2524, array( 'email_address'=>'contact3@domain.com','first_name'=>'contact 3', 'last_name'=>'','name'=>'test21 name', 'state'=>'', 'zip_code'=>'73208', 'country'=>'US', 'city'=>'', 'company'=>'', 'dob'=>'', 'phone'=>'', 'address'=>''));    



/**
 * Modify an existing contact from provided List-Id and contact-Id
 * Uncomment to view the example
 */

 // echo $rcapi->updateContact(2524, 18135541, array( 'email_address'=>'contact3_new@domain.com','first_name'=>'contact 3', 'last_name'=>'','name'=>'test21 name', 'state'=>'', 'zip_code'=>'73208', 'country'=>'US', 'city'=>'', 'company'=>'', 'dob'=>'', 'phone'=>'', 'address'=>'') ); exit;



/**
 * Delete an existing contact from provided List-Id and contact-Id
 * Uncomment to view the example
 */
 
// echo $rcapi->removeContacts(2524, 18135541); exit;

 

 

/**
 * End of example.php
 *
*/